/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prj_poo2_estacionamento.dao;

import com.poo.prj_poo2_estacionamento.models.Pessoa;
import com.poo.prj_poo2_estacionamento.models.Veiculo;
import com.poo.prj_poo2_estacionamento.util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Iftm
 */
public class VeiculoDAO {
    Connection conn;
    
    public VeiculoDAO(){
        conn = new Conexao().conectar();
    }
    
    public Veiculo salvar(Veiculo v){
        try{
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO veiculo(marca, modelo, placa, ano, idpessoa) values (?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, v.getMarca());
            stmt.setString(2, v.getModelo());
            stmt.setString(3, v.getPlaca());
            stmt.setInt(4, v.getAno());
            stmt.setInt(5, v.getPessoa().getIdpessoa());
            stmt.execute();
            
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                v.setIdVeiculo(rs.getInt("idVeiculo"));
            }
            else{
                v.setIdVeiculo(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        
        return v;
    }
    
    public int editar(Veiculo v){
        int verif = 0;
        try{
            PreparedStatement stmt = conn.prepareStatement("UPDATE veiculo SET marca = ?, modelo = ?, placa = ?, ano = ?, idpessoa = ? WHERE idveiculo = ?");
            stmt.setString(1, v.getMarca());
            stmt.setString(2, v.getModelo());
            stmt.setString(3, v.getPlaca());
            stmt.setInt(4, v.getAno());
            stmt.setInt(5, v.getPessoa().getIdpessoa());
            stmt.setInt(6, v.getIdVeiculo());
            verif = stmt.executeUpdate();
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return verif;
    }
    
    public int excluir(Veiculo v){
        int verif = 0;
        
        try{
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM veiculo WHERE idveiculo = ?");
            stmt.setInt(1, v.getIdVeiculo());
            verif = stmt.executeUpdate();
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return verif;
    }
    
    public List<Veiculo> getVeiculos(){
        List<Veiculo> lstV = new ArrayList<>();
        ResultSet rs;
        
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM veiculo");
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstV.add(getVeiculo(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstV;
    }
    
    public Veiculo getVeiculos(int idveiculo){
        Veiculo v = new Veiculo();
        ResultSet rs;
        
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM veiculo WHERE idveiculo = ?", ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ppStmt.setInt(1, idveiculo);
            rs = ppStmt.executeQuery();
            rs.first();
            v = getVeiculo(rs);
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return v;
    }
    
    public List<Veiculo> getVeiculos(String conteudo){
        List<Veiculo> lstV = new ArrayList<>();
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM veiculo WHERE modelo ILIKE ? OR placa ILIKE ?");
            ppStmt.setString(1, conteudo+ "%");
            ppStmt.setString(2, conteudo+ "%");
            rs = ppStmt.executeQuery();
            
            while(rs.next()){
                lstV.add(getVeiculo(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstV;
    }
    
    public Veiculo getVeiculo(ResultSet rs) throws SQLException{
        Veiculo v = new Veiculo();
        PessoaDAO pDAO = new PessoaDAO();
        
        int idpessoa = rs.getInt("idpessoa");
        Pessoa p = pDAO.getPessoas(idpessoa);
        
        v.setIdVeiculo(rs.getInt("idveiculo"));
        v.setMarca(rs.getString("marca"));
        v.setModelo(rs.getString("modelo"));
        v.setPlaca(rs.getString("placa"));
        v.setAno(rs.getInt("ano"));
        v.setPessoa(p);
        
        return v;
    }
}
