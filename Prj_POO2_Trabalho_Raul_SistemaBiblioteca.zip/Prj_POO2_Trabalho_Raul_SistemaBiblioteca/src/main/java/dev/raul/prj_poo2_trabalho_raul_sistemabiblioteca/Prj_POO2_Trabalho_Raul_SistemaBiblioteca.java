/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package dev.raul.prj_poo2_trabalho_raul_sistemabiblioteca;

/**
 *
 * @author Raul
 */
public class Prj_POO2_Trabalho_Raul_SistemaBiblioteca {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
