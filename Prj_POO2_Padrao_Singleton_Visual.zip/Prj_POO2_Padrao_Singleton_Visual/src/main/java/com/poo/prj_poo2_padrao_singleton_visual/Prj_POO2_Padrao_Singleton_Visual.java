/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prj_poo2_padrao_singleton_visual;

import com.poo.prj_poo2_padrao_singleton_visual.forms.FormPrincipal;

/**
 *
 * @author Iftm
 */
public class Prj_POO2_Padrao_Singleton_Visual {

    public static void main(String[] args){
        new FormPrincipal().setVisible(true);
    }
}
