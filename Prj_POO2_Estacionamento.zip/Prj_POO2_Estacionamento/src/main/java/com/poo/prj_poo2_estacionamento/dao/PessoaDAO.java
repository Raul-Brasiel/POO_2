/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prj_poo2_estacionamento.dao;

import com.poo.prj_poo2_estacionamento.models.Pessoa;
import com.poo.prj_poo2_estacionamento.util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Iftm
 */
public class PessoaDAO {
    Connection conn;
    
    public PessoaDAO(){
        conn = new Conexao().conectar();
    }
    
    public Pessoa salvar(Pessoa p){
        try{
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO pessoa(nome,cpf) values (?,?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getCpf());
            stmt.execute();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                p.setIdpessoa(rs.getInt("idpessoa"));
            }
            else{
                p.setIdpessoa(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return p;
    }
    
    public int editar(Pessoa p){
        int verif = 0;
        try{
            PreparedStatement stmt = conn.prepareStatement("UPDATE pessoa SET nome = ?, cpf = ? WHERE idpessoa = ?");
            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getCpf());
            stmt.setInt(3, p.getIdpessoa());
            verif = stmt.executeUpdate();
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return verif;
    }
    
    public int excluir(Pessoa p){
        int verif = 0;
        try{
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM pessoa WHERE idpessoa = ?");
            stmt.setInt(1, p.getIdpessoa());
            verif = stmt.executeUpdate();
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return verif;
    }
    
    public List<Pessoa> getPessoas(){
        List<Pessoa> lstP = new ArrayList<>();
        ResultSet rs;
        
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM pessoa");
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstP.add(getPessoa(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstP;
    }
    
    public Pessoa getPessoas(int idpessoa){
        Pessoa p = new Pessoa();
        ResultSet rs;
        
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM pessoa WHERE idpessoa = ?", ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ppStmt.setInt(1, idpessoa);
            rs = ppStmt.executeQuery();
            rs.first();
            p = getPessoa(rs);
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return p;
    }
    
    public List<Pessoa> getPessoas(String conteudo){
        List<Pessoa> lstP = new ArrayList<>();
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM pessoa WHERE nome ILIKE ? OR cpf = ?");
            ppStmt.setString(1, conteudo+ "%");
            ppStmt.setString(2, conteudo);
            rs = ppStmt.executeQuery();
            
            while(rs.next()){
                lstP.add(getPessoa(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstP;
    }
    
    public Pessoa getPessoa(ResultSet rs) throws SQLException{
        Pessoa p = new Pessoa();
        
        p.setIdpessoa(rs.getInt("idpessoa"));
        p.setNome(rs.getString("nome"));
        p.setCpf(rs.getString("cpf"));
        
        return p;
    }
}
