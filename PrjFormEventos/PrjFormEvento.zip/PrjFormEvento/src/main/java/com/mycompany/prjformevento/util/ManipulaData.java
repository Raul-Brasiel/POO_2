package com.mycompany.prjformevento.util;

/**
 *
 * @author IFTM
 */
public class ManipulaData {
    
}
