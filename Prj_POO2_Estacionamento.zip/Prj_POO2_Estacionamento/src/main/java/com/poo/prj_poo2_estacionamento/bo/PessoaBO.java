/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prj_poo2_estacionamento.bo;

import com.poo.prj_poo2_estacionamento.dao.PessoaDAO;
import com.poo.prj_poo2_estacionamento.models.Pessoa;
import java.util.List;

/**
 *
 * @author Iftm
 */
public class PessoaBO {
    PessoaDAO pDAO;
    
    public PessoaBO(){
        pDAO = new PessoaDAO();
    }
    public Pessoa salvar(Pessoa p){
        return pDAO.salvar(p);
    }
    public List<Pessoa> getPessoas(String conteudo){
        return pDAO.getPessoas(conteudo);
    }
    public int editar(Pessoa p){
        return pDAO.editar(p);
    }
    public int excluir(Pessoa p){
        return pDAO.excluir(p);
    }
}
