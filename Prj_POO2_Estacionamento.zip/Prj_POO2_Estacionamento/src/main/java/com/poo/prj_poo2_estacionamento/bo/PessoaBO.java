/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prj_poo2_estacionamento.bo;

import com.poo.prj_poo2_estacionamento.dao.PessoaDAO;
import com.poo.prj_poo2_estacionamento.models.Pessoa;

/**
 *
 * @author Iftm
 */
public class PessoaBO {
    PessoaDAO pDAO;
    
    public PessoaBO(){
        pDAO = new PessoaDAO();
    }
    public void salvar(Pessoa p){
        pDAO.salvar(p);
    }
}
