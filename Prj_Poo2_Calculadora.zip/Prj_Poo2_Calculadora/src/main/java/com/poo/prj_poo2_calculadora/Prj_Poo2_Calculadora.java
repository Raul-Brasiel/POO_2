/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prj_poo2_calculadora;

import com.poo.prj_poo2_calculadora.forms.Form_Principal;


/**
 *
 * @author Iftm
 */
public class Prj_Poo2_Calculadora {

    public static void main(String[] args) {
        new Form_Principal().setVisible(true);
    }
}
