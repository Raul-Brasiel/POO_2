/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prj_poo2_estacionamento;

/**
 *
 * @author Iftm
 */
public class Prj_POO2_Estacionamento {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
