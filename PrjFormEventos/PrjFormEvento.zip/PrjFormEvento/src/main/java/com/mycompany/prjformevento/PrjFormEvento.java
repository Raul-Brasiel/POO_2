package com.mycompany.prjformevento;

/**
 *
 * @author IFTM
 */
public class PrjFormEvento {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
