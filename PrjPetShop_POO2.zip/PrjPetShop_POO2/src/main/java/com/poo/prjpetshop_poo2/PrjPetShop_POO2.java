package com.poo.prjpetshop_poo2;

import com.poo.prjpetshop_poo2.forms.FormCadastroPessoa;

/**
 *
 * @author IFTM
 */
public class PrjPetShop_POO2 {

    public static void main(String[] args){
        FormCadastroPessoa form = new FormCadastroPessoa();
        form.setVisible(true);
    }
}
