/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prj_poo2_petshop;

import com.mycompany.prj_poo2_petshop.forms.FormPrincipal;

/**
 *
 * @author raul_brasiel
 */
public class Prj_POO2_PetShop {

    public static void main(String[] args) {
        new FormPrincipal().setVisible(true);
    }
}
