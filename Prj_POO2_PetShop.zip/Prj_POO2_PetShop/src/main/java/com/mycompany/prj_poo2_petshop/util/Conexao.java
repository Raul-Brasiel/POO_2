/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prj_poo2_petshop.util;

import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author raul_brasiel
 */
public class Conexao {
    final private String driver="org.postgresql.Driver";
    final private String url="jdbc:postgresql://localhost:5432/bd_petshop";
    final private String usuario = "postgres";
    final private String senha = "postgres";
    
    public Connection conectar(){
        Connection conn = null;
        
        try{
            Class.forName(driver);
            conn.DriverManager.getConnection(url,usuario,senha);
        }
        catch(ClassNotFoundException ex){
            ex.printStackTrace();
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        
        return conn;
    }
}
