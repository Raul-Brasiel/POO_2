/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dev.raul.prj_poo2_trabalho_raul_sistemabiblioteca.model;

/**
 *
 * @author Raul
 */
public class LivroDigital extends Livro{
    private String formato;
}