package com.mycompany.prjformevento.objetos;

/**
 *
 * @author IFTM
 */
public class Pessoa {
    
}
