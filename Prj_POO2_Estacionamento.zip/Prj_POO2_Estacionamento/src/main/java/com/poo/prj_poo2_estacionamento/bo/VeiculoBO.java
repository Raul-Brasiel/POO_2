/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prj_poo2_estacionamento.bo;

import com.poo.prj_poo2_estacionamento.dao.VeiculoDAO;
import com.poo.prj_poo2_estacionamento.models.Veiculo;
import java.util.List;

/**
 *
 * @author Iftm
 */
public class VeiculoBO {
    VeiculoDAO vDAO;
    
    public VeiculoBO(){
        vDAO = new VeiculoDAO();
    }
  
    public Veiculo salvar(Veiculo v){
        return vDAO.salvar(v);
    }
    public List<Veiculo> getVeiculos(String conteudo){
        return vDAO.getVeiculos(conteudo);
    }
    public int editar(Veiculo v){
        return vDAO.editar(v);
    }
    public int excluir(Veiculo v){
        return vDAO.excluir(v);
    }
}
