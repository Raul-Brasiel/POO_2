/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prj_poo2_estacionamento;

import com.poo.prj_poo2_estacionamento.forms.FormPessoa;
import com.poo.prj_poo2_estacionamento.util.Conexao;

/**
 *
 * @author Iftm
 */
public class Prj_POO2_Estacionamento {

    public static void main(String[] args) {
        new Conexao().conectar();
    }
}