/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dev.raul.prj_poo2_trabalho_raul_sistemabiblioteca.model;

/**
 *
 * @author Raul
 */
public class Cadastro {
    private int id;
    private String numero_carteirinha;
    private String data_cadastro;
    private String data_validade;
    private int limite_emprestimos;
    private boolean status;
    private Membro membro;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNumero_carteirinha() {
        return numero_carteirinha;
    }

    public void setNumero_carteirinha(String numero_carteirinha) {
        this.numero_carteirinha = numero_carteirinha;
    }

    public String getData_cadastro() {
        return data_cadastro;
    }

    public void setData_cadastro(String data_cadastro) {
        this.data_cadastro = data_cadastro;
    }

    public String getData_validade() {
        return data_validade;
    }

    public void setData_validade(String data_validade) {
        this.data_validade = data_validade;
    }

    public int getLimite_emprestimos() {
        return limite_emprestimos;
    }

    public void setLimite_emprestimos(int limite_emprestimos) {
        this.limite_emprestimos = limite_emprestimos;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public Membro getMembro() {
        return membro;
    }

    public void setMembro(Membro membro) {
        this.membro = membro;
    }
    
    
}